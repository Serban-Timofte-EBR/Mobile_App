package eu.ase.ro.a6_costum.model;

public enum Size {
    XS,
    S,
    M,
    L,
    XL,
    XXL
}
